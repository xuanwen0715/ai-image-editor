"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Upload, Sparkles } from "lucide-react"

export function Editor() {
  const [prompt, setPrompt] = useState("")
  const [selectedImage, setSelectedImage] = useState<string | null>(null)

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => {
        setSelectedImage(e.target?.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  return (
    <section id="editor" className="py-20 bg-background">
      <div className="container">
        <div className="mx-auto max-w-5xl text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-foreground">Try The AI Editor</h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Experience the power of nano-banana's natural language image editing. Transform any photo with simple text
            commands
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6 max-w-6xl mx-auto">
          {/* Prompt Engine */}
          <Card className="p-6 border-2 border-primary/20">
            <div className="mb-4 flex items-center gap-2">
              <div className="rounded-lg bg-primary/10 p-2">
                <Sparkles className="h-5 w-5 text-primary" />
              </div>
              <h3 className="text-lg font-semibold text-foreground">Prompt Engine</h3>
            </div>
            <p className="text-sm text-muted-foreground mb-4">Transform your image with AI-powered editing</p>

            {/* Image Upload */}
            <div className="mb-4">
              <label className="block text-sm font-medium mb-2 text-foreground">Reference Image</label>
              <div className="border-2 border-dashed border-border rounded-lg p-8 text-center hover:border-primary/50 transition-colors cursor-pointer">
                <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" id="image-upload" />
                <label htmlFor="image-upload" className="cursor-pointer">
                  {selectedImage ? (
                    <img
                      src={selectedImage || "/placeholder.svg"}
                      alt="Uploaded"
                      className="max-h-40 mx-auto rounded-lg"
                    />
                  ) : (
                    <>
                      <Upload className="h-10 w-10 mx-auto mb-2 text-muted-foreground" />
                      <p className="text-sm text-muted-foreground">
                        Add Image
                        <br />
                        <span className="text-xs">Max 50MB</span>
                      </p>
                    </>
                  )}
                </label>
              </div>
            </div>

            {/* Main Prompt */}
            <div className="mb-4">
              <label className="block text-sm font-medium mb-2 text-foreground">Main Prompt</label>
              <Textarea
                placeholder="A futuristic city powered by nano technology, golden hour lighting, ultra detailed..."
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                className="min-h-32 resize-none"
              />
            </div>

            <Button className="w-full bg-primary text-primary-foreground hover:bg-primary/90" size="lg">
              <Sparkles className="mr-2 h-4 w-4" />
              Generate Now
            </Button>
          </Card>

          {/* Output Gallery */}
          <Card className="p-6 border-2 border-border">
            <div className="mb-4 flex items-center gap-2">
              <div className="rounded-lg bg-secondary p-2">
                <Upload className="h-5 w-5 text-foreground" />
              </div>
              <h3 className="text-lg font-semibold text-foreground">Output Gallery</h3>
            </div>
            <p className="text-sm text-muted-foreground mb-4">Your ultra-fast AI creations appear here instantly</p>

            <div className="flex items-center justify-center min-h-80 border-2 border-dashed border-border rounded-lg bg-secondary/30">
              <div className="text-center">
                <div className="mx-auto mb-4 h-20 w-20 rounded-full bg-secondary flex items-center justify-center">
                  <Upload className="h-10 w-10 text-muted-foreground" />
                </div>
                <p className="text-lg font-medium text-foreground mb-2">Ready for Instant generation</p>
                <p className="text-sm text-muted-foreground">Enter your prompt and unleash the power</p>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </section>
  )
}
